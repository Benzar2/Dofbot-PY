## README

yolov5 source code: https://github.com/ultralytics/yolov5

weight file：https://github.com/ultralytics/yolov5/releases

### 1、folder structure

```python
├── garbage
│   ├── garbage.yaml
│   ├── Get_garbageData.py # Automatically generate the py file of the corresponding dataset (needs more)
│   ├── image              # Save the original image (target image to be recognized) folder
│   ├── texture            # Folder for background images (needs more)
│   └── train        
│       ├── images         # The image folder where the dataset is stored
│       └── labels         # Label folder to hold datasets
├── inference
│   ├── images             # test intout image path folder
│   └── output             # Test output image path folder
├── models
├── utils
├── README_CN.md
├── README_EN.md
├── runs
│   └── exp0
│       ├── results.png            # Training result picture
│       ├── results.txt            # training log information
│       ├── test_batch0_pred.jpg   # prediction picture
│       ├── train_batch0.jpg       # training pictures
│       └── weights
│           ├── best.pt           # The best training model (generally choose it)
│           └── last.pt           # The last trained model
├── test.py                       
├── train.py                      # training file
├── detect.py                     # detect file
└── weights                       # Folder where weight files (pretrained models) are stored
    ├── download_weights.sh
    └── yolov5s.pt
```

Note: There are verification pictures in the runs/exp file. 
    After training an epoch, go and see to verify whether the pictures are correct. 
    If they are not correct, adjust them quickly. 
    Otherwise, you have to retrain after training all the adjustments.

Label format: label x y w h 
The value of x,y,w,h is the position where the image length and height are pressed [0:1]

### 2、Environmental requirements

```
Cython
matplotlib>=3.2.2
numpy>=1.18.5
opencv-python>=4.1.2
pillow
PyYAML>=5.3
scipy>=1.4.1
tensorboard>=2.2
torch>=1.6.0
torchvision>=0.7.0
tqdm>=4.41.0
```

Installation example

```
pip install Cython
```

### 3、Custom training dataset

Make a yaml file like garbage.yaml:

```python
train: ./garbage/train/images/           # training set image path
val:    ./garbage/train/images/          # Validation set image path (also separate from training set)
nc: 16                                   # Number of categories
names: ["Zip_top_can", "Apple_core"...]  # classification name
```

Modify train.py

```python
parser.add_argument('--weights', type=str, default='./weights/yolov5s.pt', help='initial weights path') # Line 381: Pretrained weights
parser.add_argument('--data', type=str, default='./garbage/garbage.yaml', help='data.yaml path')        # Line 383: Custom training file
parser.add_argument('--epochs', type=int, default=300)                                      # Line 385: Customize training epochs, how many epochs to train.
```

Other places according to your needs.

Modify the second line of the yaml file of the yolov 5 neural network, and use which weight file to modify the corresponding yaml file ()

Here we are using yolov 5 s.yaml, so just modify the second line of the models/yolov 5 s.yaml file

```python
nc: 16  # number of classes
```

### 4、manual

- After configuring according to the above process 
- Fill in more background images in the path of yolov5-pytorch/garbage/texture ([more]) 
- Run the Get_garbageData.py file to obtain the data set (line 134 can be modified to generate data number of sets [more]) 
- run train.py file to start training 
- run detect.py to predict (line 134 can modify the path to use the prediction model)




