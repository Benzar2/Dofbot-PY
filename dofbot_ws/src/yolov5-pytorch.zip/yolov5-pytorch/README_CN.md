## README

yolov5源码: https://github.com/ultralytics/yolov5

权重文件：https://github.com/ultralytics/yolov5/releases

### 1、文件夹结构

```python
├── garbage
│   ├── garbage.yaml
│   ├── Get_garbageData.py # 自动生成对应的数据集的py文件(需要多一些)
│   ├── image              # 存放原图像(要识别的目标图像)文件夹
│   ├── texture            # 存放背景图像(需要多一些)文件夹
│   └── train        
│       ├── images         # 存放数据集的图片文件夹
│       └── labels         # 存放数据集的标签 文件夹
├── inference
│   ├── images             # 测试输入图片图片文件夹
│   └── output             # 测试输出图片路径文件夹
├── models
├── utils
├── README_CN.md
├── README_EN.md
├── runs
│   └── exp0
│       ├── results.png            # 训练结果图片
│       ├── results.txt            # 训练的日志信息
│       ├── test_batch0_pred.jpg   # 预测图片
│       ├── train_batch0.jpg       # 训练图片
│       └── weights
│           ├── best.pt           # 最好的训练模型（一般选它）
│           └── last.pt           # 最后一个训练模型
├── test.py                       # 测试文件
├── train.py                      # 训练文件
├── detect.py                     # 检测文件
└── weights                       # 存放权重文件(预训练模型)的文件夹
    ├── download_weights.sh
    └── yolov5s.pt
```

注意：在runs/exp文件里有验证图片,训练完一个epoch就去看看,验证图片是否正确，如果不正确就赶紧调整,不然训练完所有再调整就得重新训练.

标签格式:  label  x y w h 
x,y,w,h的值是将图像长和高按[0:1]所在的位置

### 2、环境要求

```
Cython
matplotlib>=3.2.2
numpy>=1.18.5
opencv-python>=4.1.2
pillow
PyYAML>=5.3
scipy>=1.4.1
tensorboard>=2.2
torch>=1.6.0
torchvision>=0.7.0
tqdm>=4.41.0
```

安装示例

```
pip install Cython
```

### 3、自定义训练数据集

制作yaml文件，例如garbage.yaml:

```python
train: ./garbage/train/images/           # 训练集图片路径
val:    ./garbage/train/images/          # 验证集图片路径(也可与训练集分开)
nc: 16                                   # 类别数量
names: ["Zip_top_can", "Apple_core"...]  # 类别名称
```

修改train.py

```python
parser.add_argument('--weights', type=str, default='./weights/yolov5s.pt', help='initial weights path') # 第381行:预训练权重
parser.add_argument('--data', type=str, default='./garbage/garbage.yaml', help='data.yaml path')        # 第383行:自定义训练文件
parser.add_argument('--epochs', type=int, default=300)                                      # 第385行:自定义训练epochs,训练多少轮.
```

其他地方根据自己需求.

修改yolov5神经网络的yaml文件第二行,用哪个权重文件修改对应的yaml文件()

这里我们使用的是yolov5s.yaml，所以修改models/yolov5s.yaml文件第二行即可

```python
nc: 16  # number of classes
```

### 4、使用流程

- 按照上面的流程配置完毕后
- 在yolov5-pytorch/garbage/texture该路径下,多多填充一些背景图片([要多一些])
- 运行Get_garbageData.py文件获得数据集(第134行可修改生成数据集的数量[要多一些])
- 运行train.py文件开始训练
- 运行detect.py进行预测(第134行可修改使用预测模型的路径)



